import auroraBg from "@/assets/aurora-bg.jpg";
import auroraRing from "@/assets/aurora-ring.png";

const Hero = () => {
  return (
    <section className="relative min-h-[100svh] w-full overflow-hidden">
      {/* Background image */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${auroraBg})` }}
      />
      {/* Soft warm wash to harmonize with palette */}
      <div className="absolute inset-0 bg-[linear-gradient(180deg,hsl(30_25%_94%/0.25)_0%,hsl(28_30%_88%/0.05)_50%,hsl(25_25%_85%/0.35)_100%)]" />

      {/* Strategic gold rings — sparse, sophisticated placement */}
      <img
        src={auroraRing}
        alt=""
        aria-hidden
        className="pointer-events-none absolute top-[6%] right-[8%] w-44 md:w-64 opacity-95 fade-in"
      />
      <img
        src={auroraRing}
        alt=""
        aria-hidden
        className="pointer-events-none absolute bottom-[10%] left-[5%] w-24 md:w-32 opacity-70 fade-in"
        style={{ animationDelay: "0.6s" }}
      />

      {/* Thin gold frame */}
      <div className="pointer-events-none absolute inset-4 md:inset-8 border border-[hsl(var(--gold)/0.3)] rounded-[2px]" />

      {/* Nav */}
      <nav className="relative z-10 container flex items-center justify-center py-8">
        <span className="text-foreground/60 text-[10px] tracking-[0.4em] uppercase">
          Direção & Estratégia em Saúde
        </span>
      </nav>

      {/* Content */}
      <div className="relative z-10 container flex min-h-[calc(100svh-160px)] flex-col items-center justify-center text-center pb-20">
        <div className="fade-up max-w-5xl">
          {/* Eyebrow with ornaments */}
          <div className="flex items-center justify-center gap-4 mb-10">
            <span className="h-px w-12 bg-[hsl(var(--gold)/0.6)]" />
            <span className="text-foreground/70 text-[11px] md:text-xs tracking-[0.5em] uppercase">
              Método Aurora
            </span>
            <span className="h-px w-12 bg-[hsl(var(--gold)/0.6)]" />
          </div>

          <h1 className="font-serif text-foreground text-5xl md:text-7xl lg:text-[8.5rem] leading-[0.95] mb-8">
            <span className="block font-light">Direção</span>
            <span className="block italic my-1 text-[hsl(var(--primary-deep))]">&amp;</span>
            <span className="block font-light">Estratégia</span>
            <span className="block italic font-extralight text-foreground/75 text-3xl md:text-5xl lg:text-6xl mt-6 tracking-wide">
              em Saúde
            </span>
          </h1>

          <div className="mx-auto mt-10 max-w-2xl">
            <p className="text-foreground/80 text-lg md:text-xl font-light leading-relaxed mb-3">
              Um modelo de consultoria baseado em direção estratégica e autonomia.
            </p>
            <p className="text-foreground/55 text-sm md:text-base font-light leading-relaxed italic">
              Para profissionais da saúde que desejam posicionamento, clareza e crescimento com consistência.
            </p>
          </div>

          <div className="mt-12 flex flex-col items-center gap-6">
            <a
              href="#posicionamento"
              className="text-foreground/50 hover:text-foreground text-[10px] tracking-[0.4em] uppercase transition-colors"
            >
              Conheça o método ↓
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
