import { Button } from "@/components/ui/button";

const FinalCTA = () => (
  <section id="aplicar" className="relative py-32 md:py-44 bg-gradient-warm overflow-hidden">
    <div className="pointer-events-none absolute -top-32 left-1/2 -translate-x-1/2 h-[500px] w-[800px] rounded-full aurora-glow glow-pulse" />
    <div className="container relative max-w-3xl text-center">
      <span className="text-xs tracking-[0.35em] uppercase text-primary mb-8 block">O próximo passo</span>
      <h2 className="font-serif text-4xl md:text-6xl lg:text-7xl text-foreground leading-tight mb-8">
        Se você busca <em className="text-gradient-gold">clareza</em>,
        posicionamento e crescimento com estratégia —
        <br />
        o Aurora é o próximo passo.
      </h2>
      <Button asChild variant="aurora" size="xl">
        <a
          href="https://www.instagram.com/mariavila.marketingmedico"
          target="_blank"
          rel="noopener noreferrer"
        >
          Quero começar agora
        </a>
      </Button>
    </div>
  </section>
);

export default FinalCTA;
