import { Check } from "lucide-react";

const items = [
  { t: "Pack de peças editáveis", d: "Templates premium prontos para personalização contínua." },
  { t: "Roteiros para vídeos e stories", d: "Estrutura narrativa para comunicação consistente." },
  { t: "Planejamento trimestral", d: "Calendário estratégico de conteúdo e ações." },
  { t: "Estratégias completas de posicionamento", d: "Diretrizes claras para autoridade no digital." },
];

const Deliverables = () => (
  <section className="relative py-28 md:py-40 bg-gradient-warm">
    <div className="container max-w-5xl">
      <div className="text-center mb-16">
        <span className="text-xs tracking-[0.35em] uppercase text-primary mb-6 block">Entregáveis</span>
        <h2 className="font-serif text-4xl md:text-6xl text-foreground leading-tight">
          Material que <em className="text-gradient-gold">trabalha por você</em>.
        </h2>
      </div>

      <ul className="space-y-4">
        {items.map((i) => (
          <li
            key={i.t}
            className="group flex items-start gap-6 bg-card/80 backdrop-blur-sm border border-primary/15 rounded-2xl p-8 hover:border-primary/40 hover:translate-x-1 transition-all duration-500"
          >
            <span className="mt-1 inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gradient-gold">
              <Check className="h-4 w-4 text-primary-deep" strokeWidth={2} />
            </span>
            <div>
              <h3 className="font-serif text-2xl text-foreground mb-1">{i.t}</h3>
              <p className="text-muted-foreground font-light">{i.d}</p>
            </div>
          </li>
        ))}
      </ul>
    </div>
  </section>
);

export default Deliverables;
