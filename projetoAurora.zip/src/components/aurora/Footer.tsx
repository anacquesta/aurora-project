import { Instagram } from "lucide-react";

const Footer = () => (
  <footer className="bg-background border-t border-primary/15 py-14">
    <div className="container flex flex-col md:flex-row items-center justify-between gap-6">
      <div>
        <p className="font-serif text-2xl text-foreground italic">aurora</p>
        <p className="text-xs tracking-[0.25em] uppercase text-muted-foreground mt-1">
          Direção & Estratégia em Saúde
        </p>
      </div>
      <a
        href="https://www.instagram.com/mariavila.marketingmedico"
        target="_blank"
        rel="noopener noreferrer"
        className="group inline-flex items-center gap-3 text-muted-foreground hover:text-primary-deep transition-colors"
      >
        <Instagram className="h-4 w-4" strokeWidth={1.5} />
        <span className="text-sm tracking-wide">@mariavila.marketingmedico</span>
      </a>
      <p className="text-xs text-muted-foreground">
        © {new Date().getFullYear()} Método Aurora. Todos os direitos reservados.
      </p>
    </div>
  </footer>
);

export default Footer;
